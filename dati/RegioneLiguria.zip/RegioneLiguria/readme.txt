
RICHIESTA N. 56097 del 07/05/2016

CARTOGRAFIA: Anagrafe Siti da Bonificare

SISTEMA DI COORDINATE: Coordinate Piane - ETRS - UTM - ETRF89 - Fuso 32

---------------------

LIVELLO:   Siti da Bonificare

File: Siti_da_BonificareSHP
Campi: 
   DESCSOSTAN :  
   MATRICEAMB :  
   INANAGRAFE :  
   TIPOITER   :  
   DATAINSERI :  
   STATOATTIV :  
   ATTIVITA   :  
   FLAG_EXPOR :  
   LOCALITA   :  
   COMUNE     :  
   CODCOMUNE  :  
   SIGLAPROVI :  
   DENOMINAZI :  
   NUMORDINER :  
   ID         :  

---------------------


